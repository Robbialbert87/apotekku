<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Detail Invoice'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('invoices.index')); ?>">Invoice</a></li>
                <li class="sep">/</li>
                <li class="current"><?php echo e($invoice->invoice_number); ?></li>
            </ol>
            <h1 class="page-header__title"><?php echo e($invoice->invoice_number); ?></h1>
            <p class="page-header__desc">
                <?php echo e($invoice->supplier->name); ?> ·
                <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->due_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->due_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                <?php if($invoice->isVoided()): ?><span class="badge-custom badge-neutral">Dibatalkan</span><?php endif; ?>
            </p>
        </div>
        <div class="page-header__actions">
            <?php if(! $invoice->isVoided() && ! $invoice->isPaid() && auth()->user()->hasPermission('payment.create')): ?>
                <a href="<?php echo e(route('payments.create', ['supplier_id' => $invoice->supplier_id, 'invoice_id' => $invoice->id])); ?>" class="btn-custom btn-success-custom">
                    <i class="bi bi-cash-stack"></i> Catat Pembayaran
                </a>
            <?php endif; ?>
            <?php if(! $invoice->isVoided() && auth()->user()->hasPermission('invoice.update')): ?>
                <a href="<?php echo e(route('invoices.edit', $invoice)); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-pencil"></i> Ubah</a>
            <?php endif; ?>
            <button type="button" class="btn-custom btn-outline-custom" onclick="window.print()"><i class="bi bi-printer"></i> Cetak</button>
        </div>
    </div>

    <?php if($invoice->isVoided()): ?>
        <div class="alert-custom alert-danger-custom" role="alert">
            <i class="bi bi-x-circle-fill"></i>
            <div>
                <div class="alert-title">Invoice dibatalkan</div>
                <?php echo e($invoice->void_reason); ?> — <?php echo e($invoice->voider?->name ?? 'Sistem'); ?>, <?php echo e(Format::tanggalWaktu($invoice->voided_at)); ?>

            </div>
        </div>
    <?php endif; ?>

    <div class="content-row">
        <div class="card-custom">
            <div class="card-custom__header"><h3>Informasi Invoice</h3></div>
            <div class="card-custom__body">
                <div class="detail-grid detail-grid--3">
                    <div class="detail-item">
                        <div class="detail-item__label">Supplier</div>
                        <div class="detail-item__value"><a href="<?php echo e(route('suppliers.show', $invoice->supplier)); ?>"><?php echo e($invoice->supplier->name); ?></a></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Tanggal Invoice</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggal($invoice->invoice_date)); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Tanggal Diterima</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggal($invoice->received_date)); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Jatuh Tempo</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggal($invoice->due_date)); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Diinput Oleh</div>
                        <div class="detail-item__value"><?php echo e($invoice->creator?->name ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Terakhir Diubah</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggalWaktu($invoice->updated_at)); ?></div>
                    </div>
                </div>

                <?php if($invoice->notes): ?>
                    <div style="margin-top:var(--space-5);">
                        <div class="detail-item__label">Catatan</div>
                        <p style="margin:0;"><?php echo e($invoice->notes); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-custom">
            <div class="card-custom__header"><h3>Ringkasan</h3></div>
            <div class="card-custom__body">
                <div class="summary-box">
                    <div class="summary-row"><span>Total Tagihan</span><span class="money"><?php echo e(Format::rupiah($invoice->total_amount)); ?></span></div>
                    <div class="summary-row"><span>Sudah Dibayar</span><span class="money" style="color:var(--color-success);"><?php echo e(Format::rupiah($invoice->paid_amount)); ?></span></div>
                    <div class="summary-row summary-row--total"><span>Sisa Tagihan</span><span class="money" style="color:var(--color-danger);"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></span></div>
                </div>

                <div style="margin-top:var(--space-4);">
                    <div class="detail-item__label">Status Pembayaran</div>
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                </div>
                <div style="margin-top:var(--space-3);">
                    <div class="detail-item__label">Status Jatuh Tempo</div>
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->due_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->due_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header"><h3>Rincian Obat</h3></div>
        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <thead><tr><th>Nama Obat</th><th class="text-end">Jumlah</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Nama Obat"><?php echo e($item->name); ?></td>
                            <td data-label="Jumlah" class="text-end"><?php echo e($item->quantityLabel()); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="2"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-capsule','title' => 'Tidak ada rincian obat','description' => 'Rincian obat bersifat opsional.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-capsule','title' => 'Tidak ada rincian obat','description' => 'Rincian obat bersifat opsional.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header"><h3>Lampiran</h3></div>
        <div class="card-custom__body">
            <?php if($invoice->files->isEmpty()): ?>
                <p class="text-muted text-small" style="margin:0;">Tidak ada lampiran.</p>
            <?php else: ?>
                <ul class="file-list">
                    <?php $__currentLoopData = $invoice->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="file-icon"><i class="bi <?php echo e($file->isImage() ? 'bi-image' : 'bi-file-earmark-pdf'); ?>"></i></div>
                            <div class="file-meta">
                                <div class="file-name"><?php echo e($file->original_name); ?></div>
                                <div class="file-size"><?php echo e(Format::fileSize($file->size)); ?> · <?php echo e($file->uploader?->name ?? '-'); ?></div>
                            </div>
                            <a href="<?php echo e(route('invoices.files.show', [$invoice, $file])); ?>" target="_blank" class="btn-custom btn-ghost-custom btn-sm-custom" title="Lihat"><i class="bi bi-eye"></i></a>
                            <a href="<?php echo e(route('invoices.files.show', [$invoice, $file, 'download' => 1])); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Unduh"><i class="bi bi-download"></i></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header"><h3>Riwayat Pembayaran</h3></div>
        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <thead><tr><th>No. Transaksi</th><th>Tanggal</th><th>Metode</th><th class="text-end">Nominal</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $invoice->allocations->sortByDesc(fn ($allocation) => $allocation->payment->payment_date); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="No. Transaksi">
                                <a href="<?php echo e(route('payments.show', $allocation->payment)); ?>"><strong><?php echo e($allocation->payment->payment_number); ?></strong></a>
                            </td>
                            <td data-label="Tanggal"><?php echo e(Format::tanggal($allocation->payment->payment_date)); ?></td>
                            <td data-label="Metode"><?php echo e($allocation->payment->method->label()); ?></td>
                            <td data-label="Nominal" class="text-end money"><?php echo e(Format::rupiah($allocation->amount)); ?></td>
                            <td data-label="Status">
                                <span class="badge-custom <?php echo e($allocation->payment->isCancelled() ? 'badge-neutral' : 'badge-success'); ?>">
                                    <?php echo e($allocation->payment->status->label()); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-cash-stack','title' => 'Belum ada pembayaran']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-cash-stack','title' => 'Belum ada pembayaran']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="content-row">
        <div class="card-custom">
            <div class="card-custom__header"><h3>Log Aktivitas</h3></div>
            <div class="card-custom__body">
                <ul class="timeline-custom">
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="timeline-item">
                            <span class="timeline-dot"></span>
                            <div>
                                <div class="timeline-item__title"><?php echo e($log->description); ?></div>
                                <div class="timeline-item__time"><?php echo e($log->user?->name ?? 'Sistem'); ?> · <?php echo e(Format::tanggalWaktu($log->created_at)); ?></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-muted text-small">Belum ada aktivitas.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <?php if(! $invoice->isVoided() && auth()->user()->hasPermission('invoice.void')): ?>
            <div class="card-custom">
                <div class="card-custom__header"><h3>Batalkan Invoice</h3></div>
                <div class="card-custom__body">
                    <p class="text-muted text-small">Invoice yang sudah memiliki pembayaran tidak dapat dibatalkan. Batalkan pembayaran terlebih dahulu.</p>
                    <form action="<?php echo e(route('invoices.void', $invoice)); ?>" method="POST" data-confirm="Batalkan invoice ini? Tindakan ini tercatat di log aktivitas.">
                        <?php echo csrf_field(); ?>
                        <label class="form-label-custom" for="void_reason">Alasan Pembatalan <span class="text-danger">*</span></label>
                        <textarea id="void_reason" name="void_reason" rows="3" class="form-control-custom" required maxlength="500" placeholder="Contoh: salah input supplier."><?php echo e(old('void_reason')); ?></textarea>
                        <div class="form-actions" style="justify-content:flex-start;">
                            <button type="submit" class="btn-custom btn-danger-custom"><i class="bi bi-x-circle"></i> Batalkan Invoice</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\invoices\show.blade.php ENDPATH**/ ?>