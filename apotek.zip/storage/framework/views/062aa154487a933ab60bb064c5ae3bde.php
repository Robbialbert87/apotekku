<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['icon' => 'bi-inbox', 'title' => 'Belum ada data', 'description' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['icon' => 'bi-inbox', 'title' => 'Belum ada data', 'description' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="empty-state" style="text-align:center; padding:var(--space-8) var(--space-4);">
    <i class="bi <?php echo e($icon); ?>" style="font-size:2rem; color:var(--color-text-muted); display:block; margin-bottom:var(--space-3);"></i>
    <div style="font-weight:var(--fw-semibold); margin-bottom:4px;"><?php echo e($title); ?></div>
    <?php if($description): ?>
        <p class="text-muted text-small" style="margin:0;"><?php echo e($description); ?></p>
    <?php endif; ?>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/components/empty-state.blade.php ENDPATH**/ ?>