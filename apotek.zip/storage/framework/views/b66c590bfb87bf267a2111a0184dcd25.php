<?php $__env->startSection('title', 'Supplier'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Supplier</li>
            </ol>
            <h1 class="page-header__title">Supplier</h1>
            <p class="page-header__desc">Kelola data supplier obat dan kontak yang dapat dihubungi.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('supplier.create')): ?>
                <button type="button" class="btn-custom btn-primary-custom" data-modal-open="modalSupplierCreate">
                    <i class="bi bi-plus-lg"></i> Supplier Baru
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header" style="flex-wrap:wrap; gap:12px;">
            <form action="<?php echo e(route('suppliers.index')); ?>" method="GET" class="filter-bar w-100">
                <div class="filter-field filter-field--grow">
                    <label class="form-label-custom" for="search">Cari</label>
                    <div class="input-group-custom">
                        <i class="bi bi-search"></i>
                        <input type="search" id="search" name="search" class="form-control-custom" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Nama supplier, kontak, atau telepon...">
                    </div>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="status">Status</label>
                    <select name="status" id="status" class="form-select-custom form-control-custom">
                        <option value="">Semua status</option>
                        <option value="active" <?php if(($filters['status'] ?? '') === 'active'): echo 'selected'; endif; ?>>Aktif</option>
                        <option value="inactive" <?php if(($filters['status'] ?? '') === 'inactive'): echo 'selected'; endif; ?>>Nonaktif</option>
                    </select>
                </div>
                <div class="filter-actions">
                    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-funnel"></i> Terapkan</button>
                    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn-custom btn-outline-custom">Reset</a>
                </div>
            </form>
        </div>

        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom datatable" id="table-suppliers">
                <thead>
                    <tr><th>Nama</th><th>Kontak</th><th>Telepon</th><th>Invoice</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Nama">
                                <a href="<?php echo e(route('suppliers.show', $supplier)); ?>"><strong><?php echo e($supplier->name); ?></strong></a>
                                <div class="cell-sub"><?php echo e(\Illuminate\Support\Str::limit($supplier->address, 55)); ?></div>
                            </td>
                            <td data-label="Kontak"><?php echo e($supplier->contact_name ?: '-'); ?></td>
                            <td data-label="Telepon"><?php echo e($supplier->phone); ?></td>
                            <td data-label="Invoice"><?php echo e($supplier->invoices_count); ?></td>
                            <td data-label="Status">
                                <span class="badge-custom <?php echo e($supplier->is_active ? 'badge-success' : 'badge-neutral'); ?>">
                                    <?php echo e($supplier->is_active ? 'Aktif' : 'Nonaktif'); ?>

                                </span>
                            </td>
                            <td data-label="">
                                <div class="table-row-actions">
                                    <a href="<?php echo e(route('suppliers.show', $supplier)); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Detail"><i class="bi bi-eye"></i></a>
                                    <?php if(auth()->user()->hasPermission('supplier.update')): ?>
                                        <a href="<?php echo e(route('suppliers.edit', $supplier)); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Ubah"><i class="bi bi-pencil"></i></a>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->hasPermission('supplier.update')): ?>
                                        <form action="<?php echo e(route('suppliers.destroy', $supplier)); ?>" method="POST" data-confirm="Hapus supplier ini?" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-custom btn-ghost-custom btn-sm-custom text-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->hasPermission('supplier.deactivate')): ?>
                                        <form action="<?php echo e(route('suppliers.toggle-status', $supplier)); ?>" method="POST" data-confirm="Ubah status supplier ini?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn-custom btn-ghost-custom btn-sm-custom" title="<?php echo e($supplier->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>">
                                                <i class="bi <?php echo e($supplier->is_active ? 'bi-pause-circle' : 'bi-play-circle'); ?>"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-truck','title' => 'Supplier tidak ditemukan','description' => 'Tambahkan supplier baru atau ubah kata kunci pencarian.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-truck','title' => 'Supplier tidak ditemukan','description' => 'Tambahkan supplier baru atau ubah kata kunci pencarian.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <?php if(auth()->user()->hasPermission('supplier.create')): ?>
        <div class="modal-overlay" id="modalSupplierCreate">
            <div class="modal-custom" style="max-width:720px;">
                <div class="modal-custom__header">
                    <h3 style="margin:0;">Supplier Baru</h3>
                    <button type="button" class="icon-btn" data-modal-close aria-label="Tutup"><i class="bi bi-x-lg"></i></button>
                </div>
                <div class="modal-custom__body">
                    <?php $supplier = new \App\Models\Supplier(['is_active' => true]); ?>
                    <form action="<?php echo e(route('suppliers.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('suppliers._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </form>
                </div>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var modal = document.getElementById('modalSupplierCreate');
                    if (modal) modal.classList.add('is-open');
                });
            </script>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/suppliers/index.blade.php ENDPATH**/ ?>