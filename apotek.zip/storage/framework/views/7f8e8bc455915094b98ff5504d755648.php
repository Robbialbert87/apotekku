<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Pengguna'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Pengguna</li>
            </ol>
            <h1 class="page-header__title">Pengguna</h1>
            <p class="page-header__desc">Kelola akun admin dan karyawan beserta perannya.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('role.view')): ?>
                <a href="<?php echo e(route('roles.index')); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-shield-lock"></i> Peran &amp; Hak Akses</a>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('user.create')): ?>
                <a href="<?php echo e(route('users.create')); ?>" class="btn-custom btn-primary-custom"><i class="bi bi-person-plus"></i> Pengguna Baru</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header" style="flex-wrap:wrap; gap:12px;">
            <form action="<?php echo e(route('users.index')); ?>" method="GET" class="filter-bar w-100">
                <div class="filter-field filter-field--grow">
                    <label class="form-label-custom" for="search">Cari</label>
                    <div class="input-group-custom">
                        <i class="bi bi-search"></i>
                        <input type="search" id="search" name="search" class="form-control-custom" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Nama atau email...">
                    </div>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="role_id">Peran</label>
                    <select name="role_id" id="role_id" class="form-select-custom form-control-custom">
                        <option value="">Semua peran</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php if((string) ($filters['role_id'] ?? '') === (string) $role->id): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="status">Status</label>
                    <select name="status" id="status" class="form-select-custom form-control-custom">
                        <option value="">Semua</option>
                        <option value="active" <?php if(($filters['status'] ?? '') === 'active'): echo 'selected'; endif; ?>>Aktif</option>
                        <option value="inactive" <?php if(($filters['status'] ?? '') === 'inactive'): echo 'selected'; endif; ?>>Nonaktif</option>
                    </select>
                </div>
                <div class="filter-actions">
                    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-funnel"></i> Terapkan</button>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn-custom btn-outline-custom">Reset</a>
                </div>
            </form>
        </div>

        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom datatable" id="table-users">
                <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Status</th><th>Terakhir Masuk</th><th></th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Nama">
                                <div class="cluster gap-2">
                                    <div class="avatar" style="width:32px;height:32px;font-size:11px;"><?php echo e($user->initials()); ?></div>
                                    <div>
                                        <strong><?php echo e($user->name); ?></strong>
                                        <?php if($user->is(auth()->user())): ?>
                                            <div class="cell-sub">Akun Anda</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td data-label="Email"><?php echo e($user->email); ?></td>
                            <td data-label="Peran"><?php echo e($user->role?->name ?? 'Tanpa peran'); ?></td>
                            <td data-label="Status"><span class="badge-custom <?php echo e($user->is_active ? 'badge-success' : 'badge-neutral'); ?>"><?php echo e($user->is_active ? 'Aktif' : 'Nonaktif'); ?></span></td>
                            <td data-label="Terakhir Masuk"><?php echo e($user->last_login_at ? Format::tanggalWaktu($user->last_login_at) : '-'); ?></td>
                            <td data-label="">
                                <div class="table-row-actions">
                                    <?php if(auth()->user()->hasPermission('user.update')): ?>
                                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Ubah"><i class="bi bi-pencil"></i></a>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->hasPermission('user.update') && ! $user->is(auth()->user()) && ! $user->role?->isAdmin()): ?>
                                        <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" data-confirm="Hapus pengguna ini?" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-custom btn-ghost-custom btn-sm-custom text-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->hasPermission('user.deactivate') && ! $user->is(auth()->user())): ?>
                                        <form action="<?php echo e(route('users.toggle-status', $user)); ?>" method="POST" data-confirm="Ubah status pengguna ini?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn-custom btn-ghost-custom btn-sm-custom" title="<?php echo e($user->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>">
                                                <i class="bi <?php echo e($user->is_active ? 'bi-pause-circle' : 'bi-play-circle'); ?>"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-people','title' => 'Pengguna tidak ditemukan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-people','title' => 'Pengguna tidak ditemukan']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/users/index.blade.php ENDPATH**/ ?>