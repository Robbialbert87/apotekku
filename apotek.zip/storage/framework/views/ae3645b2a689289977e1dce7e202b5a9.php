<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Laporan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Laporan</li>
            </ol>
            <h1 class="page-header__title">Laporan</h1>
            <p class="page-header__desc">Lima jenis laporan keuangan supplier dengan filter dan ekspor CSV.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('report.export')): ?>
                <a href="<?php echo e(route('reports.export', ['type' => $type] + array_filter($filters, fn ($value) => $value !== null && $value !== ''))); ?>" class="btn-custom btn-primary-custom">
                    <i class="bi bi-download"></i> Ekspor CSV
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header" style="padding-bottom:0;">
            <div class="tabs-custom" style="border-bottom:none; flex-wrap:wrap;">
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('reports.index', ['type' => $value])); ?>" class="tab-btn <?php echo e($type === $value ? 'is-active' : ''); ?>"><?php echo e($label); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="card-custom__body">
            <form action="<?php echo e(route('reports.index')); ?>" method="GET" class="filter-bar">
                <input type="hidden" name="type" value="<?php echo e($type); ?>">

                <div class="filter-field filter-field--grow">
                    <label class="form-label-custom" for="search">Cari</label>
                    <div class="input-group-custom">
                        <i class="bi bi-search"></i>
                        <input type="search" id="search" name="search" class="form-control-custom" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Nomor invoice, supplier, atau transaksi...">
                    </div>
                </div>

                <div class="filter-field">
                    <label class="form-label-custom" for="supplier_id">Supplier</label>
                    <select name="supplier_id" id="supplier_id" class="form-select-custom form-control-custom">
                        <option value="">Semua supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>" <?php if((string) ($filters['supplier_id'] ?? '') === (string) $supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <?php if($type !== 'payments'): ?>
                    <div class="filter-field">
                        <label class="form-label-custom" for="payment_status">Status Bayar</label>
                        <select name="payment_status" id="payment_status" class="form-select-custom form-control-custom">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $paymentStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php if(($filters['payment_status'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="filter-field">
                        <label class="form-label-custom" for="due_status">Status Jatuh Tempo</label>
                        <select name="due_status" id="due_status" class="form-select-custom form-control-custom">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $dueStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php if(($filters['due_status'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php else: ?>
                    <div class="filter-field">
                        <label class="form-label-custom" for="record_status">Status Transaksi</label>
                        <select name="record_status" id="record_status" class="form-select-custom form-control-custom">
                            <option value="posted" <?php if(($filters['record_status'] ?? 'posted') === 'posted'): echo 'selected'; endif; ?>>Tercatat</option>
                            <option value="cancelled" <?php if(($filters['record_status'] ?? '') === 'cancelled'): echo 'selected'; endif; ?>>Dibatalkan</option>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="filter-field">
                    <label class="form-label-custom" for="date_from">Dari Tanggal</label>
                    <input type="date" id="date_from" name="date_from" class="form-control-custom" value="<?php echo e($filters['date_from'] ?? ''); ?>">
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="date_to">Sampai Tanggal</label>
                    <input type="date" id="date_to" name="date_to" class="form-control-custom" value="<?php echo e($filters['date_to'] ?? ''); ?>">
                </div>

                <div class="filter-actions">
                    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-funnel"></i> Terapkan</button>
                    <a href="<?php echo e(route('reports.index', ['type' => $type])); ?>" class="btn-custom btn-outline-custom">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="stat-grid stat-grid--3" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));">
        <div class="stat-card">
            <div class="stat-card__top"><div class="stat-card__icon" style="background:var(--color-primary-soft); color:var(--color-primary);"><i class="bi bi-list-check"></i></div></div>
            <div class="stat-card__value"><?php echo e(number_format($summary['count'], 0, ',', '.')); ?></div>
            <div class="stat-card__label">Jumlah Data</div>
        </div>
        <div class="stat-card">
            <div class="stat-card__top"><div class="stat-card__icon" style="background:var(--color-warning-soft); color:var(--color-warning);"><i class="bi bi-cash-stack"></i></div></div>
            <div class="stat-card__value"><?php echo e(Format::rupiah($summary['value'])); ?></div>
            <div class="stat-card__label"><?php echo e($summary['label']); ?></div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header"><h3><?php echo e($types[$type]); ?></h3></div>

        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <?php if($type === 'payments'): ?>
                    <thead><tr><th>No. Transaksi</th><th>Tanggal</th><th>Supplier</th><th>Metode</th><th>Referensi</th><th class="text-end">Nominal</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="No. Transaksi"><a href="<?php echo e(route('payments.show', $payment)); ?>"><strong><?php echo e($payment->payment_number); ?></strong></a></td>
                                <td data-label="Tanggal"><?php echo e(Format::tanggal($payment->payment_date)); ?></td>
                                <td data-label="Supplier"><?php echo e($payment->supplier->name); ?></td>
                                <td data-label="Metode"><?php echo e($payment->method->label()); ?></td>
                                <td data-label="Referensi"><?php echo e($payment->reference_number ?: '-'); ?></td>
                                <td data-label="Nominal" class="text-end money"><?php echo e(Format::rupiah($payment->total_amount)); ?></td>
                                <td data-label="Status"><span class="badge-custom <?php echo e($payment->isCancelled() ? 'badge-neutral' : 'badge-success'); ?>"><?php echo e($payment->status->label()); ?></span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-cash-stack','title' => 'Tidak ada pembayaran pada filter ini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-cash-stack','title' => 'Tidak ada pembayaran pada filter ini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                <?php elseif($type === 'suppliers'): ?>
                    <thead><tr><th>Supplier</th><th>Kontak</th><th>Invoice</th><th class="text-end">Total Tagihan</th><th class="text-end">Dibayar</th><th class="text-end">Sisa</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Supplier"><a href="<?php echo e(route('suppliers.show', $supplier)); ?>"><strong><?php echo e($supplier->name); ?></strong></a></td>
                                <td data-label="Kontak"><?php echo e($supplier->contact_name ?: '-'); ?><div class="cell-sub"><?php echo e($supplier->phone); ?></div></td>
                                <td data-label="Invoice"><?php echo e($supplier->invoices_count); ?></td>
                                <td data-label="Total Tagihan" class="text-end money"><?php echo e(Format::rupiah($supplier->billed_total ?? 0)); ?></td>
                                <td data-label="Dibayar" class="text-end money"><?php echo e(Format::rupiah($supplier->paid_total ?? 0)); ?></td>
                                <td data-label="Sisa" class="text-end money"><?php echo e(Format::rupiah($supplier->outstanding_total ?? 0)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-truck','title' => 'Tidak ada supplier pada filter ini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-truck','title' => 'Tidak ada supplier pada filter ini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                <?php elseif($type === 'due'): ?>
                    <thead><tr><th>Invoice</th><th>Supplier</th><th>Tanggal Invoice</th><th>Jatuh Tempo</th><th class="text-end">Sisa</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Invoice"><a href="<?php echo e(route('invoices.show', $invoice)); ?>"><strong><?php echo e($invoice->invoice_number); ?></strong></a></td>
                                <td data-label="Supplier"><?php echo e($invoice->supplier->name); ?></td>
                                <td data-label="Tanggal Invoice"><?php echo e(Format::tanggal($invoice->invoice_date)); ?></td>
                                <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($invoice->due_date)); ?></td>
                                <td data-label="Sisa" class="text-end money"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></td>
                                <td data-label="Status"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->due_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->due_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-calendar-check','title' => 'Tidak ada jatuh tempo pada filter ini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-calendar-check','title' => 'Tidak ada jatuh tempo pada filter ini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                <?php elseif($type === 'outstanding'): ?>
                    <thead><tr><th>Invoice</th><th>Supplier</th><th>Jatuh Tempo</th><th class="text-end">Total</th><th class="text-end">Dibayar</th><th class="text-end">Sisa</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Invoice"><a href="<?php echo e(route('invoices.show', $invoice)); ?>"><strong><?php echo e($invoice->invoice_number); ?></strong></a></td>
                                <td data-label="Supplier"><?php echo e($invoice->supplier->name); ?></td>
                                <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($invoice->due_date)); ?></td>
                                <td data-label="Total" class="text-end money"><?php echo e(Format::rupiah($invoice->total_amount)); ?></td>
                                <td data-label="Dibayar" class="text-end money"><?php echo e(Format::rupiah($invoice->paid_amount)); ?></td>
                                <td data-label="Sisa" class="text-end money"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></td>
                                <td data-label="Status"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-wallet2','title' => 'Tidak ada sisa tagihan pada filter ini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-wallet2','title' => 'Tidak ada sisa tagihan pada filter ini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                <?php else: ?>
                    <thead><tr><th>Invoice</th><th>Supplier</th><th>Tanggal Invoice</th><th>Jatuh Tempo</th><th class="text-end">Total</th><th class="text-end">Sisa</th><th>Status Bayar</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Invoice"><a href="<?php echo e(route('invoices.show', $invoice)); ?>"><strong><?php echo e($invoice->invoice_number); ?></strong></a></td>
                                <td data-label="Supplier"><?php echo e($invoice->supplier->name); ?></td>
                                <td data-label="Tanggal Invoice"><?php echo e(Format::tanggal($invoice->invoice_date)); ?></td>
                                <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($invoice->due_date)); ?></td>
                                <td data-label="Total" class="text-end money"><?php echo e(Format::rupiah($invoice->total_amount)); ?></td>
                                <td data-label="Sisa" class="text-end money"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></td>
                                <td data-label="Status Bayar"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-receipt','title' => 'Tidak ada invoice pada filter ini']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-receipt','title' => 'Tidak ada invoice pada filter ini']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                <?php endif; ?>
            </table>
        </div>

        <div style="padding:0 var(--space-5) var(--space-5);">
            <?php echo e($records->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/reports/index.blade.php ENDPATH**/ ?>