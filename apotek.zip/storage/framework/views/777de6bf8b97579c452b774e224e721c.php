<?php if(session('status')): ?>
    <div class="alert-custom alert-success-custom" role="status">
        <i class="bi bi-check-circle-fill"></i>
        <div><?php echo e(session('status')); ?></div>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert-custom alert-danger-custom" role="alert">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <div>
            <?php if($errors->count() === 1): ?>
                <?php echo e($errors->first()); ?>

            <?php else: ?>
                <ul class="mb-0" style="padding-left:18px;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\partials\flash.blade.php ENDPATH**/ ?>