<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Rencana Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Rencana Pembayaran</li>
            </ol>
            <h1 class="page-header__title">Rencana Pembayaran</h1>
            <p class="page-header__desc">Pantau invoice yang harus dibayar berdasarkan rentang jatuh tempo atau seluruh sisa tagihan.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('report.export')): ?>
                <a href="<?php echo e(route('reports.export', ['type' => 'outstanding'] + request()->only(['supplier_id', 'payment_status', 'due_status', 'date_from', 'date_to']))); ?>" class="btn-custom btn-outline-custom">
                    <i class="bi bi-download"></i> Ekspor CSV
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header" style="flex-wrap:wrap; gap:12px;">
            <div class="tabs-custom" style="border-bottom:none;">
                <a href="<?php echo e(route('plans.index', ['mode' => 'a'])); ?>" class="tab-btn <?php echo e($mode === 'a' ? 'is-active' : ''); ?>">Berdasarkan Jatuh Tempo</a>
                <a href="<?php echo e(route('plans.index', ['mode' => 'b'])); ?>" class="tab-btn <?php echo e($mode === 'b' ? 'is-active' : ''); ?>">Semua Sisa Tagihan</a>
            </div>
        </div>

        <div class="card-custom__body" style="padding-top:0;">
            <form action="<?php echo e(route('plans.index')); ?>" method="GET" class="filter-bar">
                <input type="hidden" name="mode" value="<?php echo e($mode); ?>">

                <div class="filter-field">
                    <label class="form-label-custom" for="supplier_id">Supplier</label>
                    <select name="supplier_id" id="supplier_id" class="form-select-custom form-control-custom">
                        <option value="">Semua supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>" <?php if((string) ($filters['supplier_id'] ?? '') === (string) $supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="filter-field">
                    <label class="form-label-custom" for="date_from"><?php echo e($mode === 'a' ? 'Jatuh Tempo Dari' : 'Dari Tanggal'); ?></label>
                    <input type="date" id="date_from" name="date_from" class="form-control-custom" value="<?php echo e($filters['date_from'] ?? ''); ?>">
                </div>

                <div class="filter-field">
                    <label class="form-label-custom" for="date_to"><?php echo e($mode === 'a' ? 'Jatuh Tempo Sampai' : 'Sampai Tanggal'); ?></label>
                    <input type="date" id="date_to" name="date_to" class="form-control-custom" value="<?php echo e($filters['date_to'] ?? ''); ?>">
                </div>

                <?php if($mode === 'b'): ?>
                    <div class="filter-field">
                        <label class="form-label-custom" for="payment_status">Status Bayar</label>
                        <select name="payment_status" id="payment_status" class="form-select-custom form-control-custom">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = \App\Enums\InvoicePaymentStatus::options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php if(($filters['payment_status'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="filter-field">
                        <label class="form-label-custom" for="due_status">Status Jatuh Tempo</label>
                        <select name="due_status" id="due_status" class="form-select-custom form-control-custom">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $dueStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php if(($filters['due_status'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="filter-actions">
                    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-funnel"></i> Terapkan</button>
                    <a href="<?php echo e(route('plans.index', ['mode' => $mode])); ?>" class="btn-custom btn-outline-custom">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="stat-grid stat-grid--3" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));">
        <div class="stat-card">
            <div class="stat-card__top"><div class="stat-card__icon" style="background:var(--color-primary-soft); color:var(--color-primary);"><i class="bi bi-receipt"></i></div></div>
            <div class="stat-card__value"><?php echo e(number_format($summary['count'], 0, ',', '.')); ?></div>
            <div class="stat-card__label">Invoice Belum Lunas</div>
        </div>
        <div class="stat-card">
            <div class="stat-card__top"><div class="stat-card__icon" style="background:var(--color-warning-soft); color:var(--color-warning);"><i class="bi bi-wallet2"></i></div></div>
            <div class="stat-card__value"><?php echo e(Format::rupiah($summary['total'])); ?></div>
            <div class="stat-card__label">Total Sisa Tagihan</div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header">
            <h3><?php echo e($mode === 'a' ? 'Tagihan Berdasarkan Rentang Jatuh Tempo' : 'Seluruh Sisa Tagihan'); ?></h3>
        </div>
        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <thead>
                    <tr><th>Invoice</th><th>Supplier</th><th>Jatuh Tempo</th><th>Status Jatuh Tempo</th><th class="text-end">Total</th><th class="text-end">Sisa</th><th>Status Bayar</th><th></th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Invoice">
                                <a href="<?php echo e(route('invoices.show', $invoice)); ?>"><strong><?php echo e($invoice->invoice_number); ?></strong></a>
                                <div class="cell-sub"><?php echo e(Format::tanggal($invoice->invoice_date)); ?></div>
                            </td>
                            <td data-label="Supplier"><?php echo e($invoice->supplier->name); ?></td>
                            <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($invoice->due_date)); ?></td>
                            <td data-label="Status Jatuh Tempo"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->due_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->due_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            <td data-label="Total" class="text-end money"><?php echo e(Format::rupiah($invoice->total_amount)); ?></td>
                            <td data-label="Sisa" class="text-end money"><strong><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></strong></td>
                            <td data-label="Status Bayar"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            <td data-label="">
                                <div class="table-row-actions">
                                    <?php if(auth()->user()->hasPermission('payment.create')): ?>
                                        <a href="<?php echo e(route('payments.create', ['supplier_id' => $invoice->supplier_id, 'invoice_id' => $invoice->id])); ?>" class="btn-custom btn-success-custom btn-sm-custom">
                                            <i class="bi bi-cash"></i> Bayar
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="8"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-calendar-check','title' => 'Tidak ada tagihan pada filter ini','description' => 'Coba ubah rentang tanggal atau filter supplier.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-calendar-check','title' => 'Tidak ada tagihan pada filter ini','description' => 'Coba ubah rentang tanggal atau filter supplier.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div style="padding:0 var(--space-5) var(--space-5);">
            <?php echo e($invoices->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/plans/index.blade.php ENDPATH**/ ?>