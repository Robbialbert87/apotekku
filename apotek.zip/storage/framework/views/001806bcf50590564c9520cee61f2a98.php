<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Dashboard</li>
            </ol>
            <h1 class="page-header__title">Dashboard</h1>
            <p class="page-header__desc">Ringkasan tagihan supplier dan pembayaran apotek.</p>
        </div>
        <div class="page-header__actions">
            <a href="<?php echo e(route('plans.index')); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-calendar2-check"></i> Rencana Pembayaran</a>
            <?php if(auth()->user()->hasPermission('invoice.create')): ?>
                <a href="<?php echo e(route('invoices.create')); ?>" class="btn-custom btn-primary-custom"><i class="bi bi-plus-lg"></i> Invoice Baru</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="stat-grid">
        <?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $tone = $metric['tone'];
                $bg = "var(--color-{$tone}-soft)";
                $color = "var(--color-{$tone})";
            ?>
            <div class="stat-card">
                <div class="stat-card__top">
                    <div class="stat-card__icon" style="background:<?php echo e($bg); ?>; color:<?php echo e($color); ?>;"><i class="bi <?php echo e($metric['icon']); ?>"></i></div>
                </div>
                <div class="stat-card__value">
                    <?php echo e($metric['format'] === 'currency' ? Format::rupiah($metric['value']) : number_format((int) $metric['value'], 0, ',', '.')); ?>

                </div>
                <div class="stat-card__label"><?php echo e($metric['label']); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="chart-row">
        <div class="card-custom">
            <div class="card-custom__header">
                <h3>Tagihan vs Pembayaran</h3>
                <span class="text-muted text-small">6 bulan terakhir</span>
            </div>
            <div class="card-custom__body">
                <div class="chart-canvas-wrap"><canvas id="chartMonthly" aria-label="Grafik tagihan dan pembayaran" role="img"></canvas></div>
                <div class="legend-row">
                    <span class="legend-item"><span class="legend-dot" style="background:var(--color-primary);"></span>Tagihan</span>
                    <span class="legend-item"><span class="legend-dot" style="background:var(--color-success);"></span>Pembayaran</span>
                </div>
            </div>
        </div>

        <div class="card-custom">
            <div class="card-custom__header">
                <h3>Status Pembayaran</h3>
            </div>
            <div class="card-custom__body">
                <div class="chart-canvas-wrap"><canvas id="chartStatus" aria-label="Grafik status pembayaran" role="img"></canvas></div>
                <div class="legend-row">
                    <?php $__currentLoopData = $statusChart['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="legend-item">
                            <span class="legend-dot" style="background:<?php echo e($statusChart['colors'][$index]); ?>;"></span>
                            <?php echo e($label); ?> (<?php echo e($statusChart['data'][$index]); ?>)
                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="content-row">
        <div class="card-custom">
            <div class="card-custom__header">
                <h3>Invoice Terbaru</h3>
                <a href="<?php echo e(route('invoices.index')); ?>" class="text-small">Lihat semua</a>
            </div>
            <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
                <table class="table-custom">
                    <thead>
                        <tr><th>Invoice</th><th>Supplier</th><th>Jatuh Tempo</th><th>Total</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $latestInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Invoice">
                                    <a href="<?php echo e(route('invoices.show', $invoice)); ?>"><strong><?php echo e($invoice->invoice_number); ?></strong></a>
                                    <div class="cell-sub"><?php echo e(Format::tanggal($invoice->invoice_date)); ?></div>
                                </td>
                                <td data-label="Supplier"><?php echo e($invoice->supplier->name); ?></td>
                                <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($invoice->due_date)); ?></td>
                                <td data-label="Total" class="money"><?php echo e(Format::rupiah($invoice->total_amount)); ?></td>
                                <td data-label="Status"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-receipt','title' => 'Belum ada invoice','description' => 'Invoice supplier akan tampil di sini.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-receipt','title' => 'Belum ada invoice','description' => 'Invoice supplier akan tampil di sini.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="stack gap-4">
            <div class="card-custom">
                <div class="card-custom__header">
                    <h3>Jatuh Tempo Terdekat</h3>
                    <a href="<?php echo e(route('plans.index')); ?>" class="text-small">Lihat</a>
                </div>
                <div class="card-custom__body stack gap-3">
                    <?php $__empty_1 = true; $__currentLoopData = $nearestDue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="person-card">
                            <div class="avatar"><i class="bi bi-receipt"></i></div>
                            <div class="person-card__meta">
                                <div class="person-card__name"><?php echo e($invoice->invoice_number); ?></div>
                                <div class="person-card__sub"><?php echo e($invoice->supplier->name); ?> · <?php echo e(Format::tanggal($invoice->due_date)); ?></div>
                            </div>
                            <div class="text-end">
                                <div class="text-small money"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></div>
                                <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->due_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->due_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-calendar-check','title' => 'Tidak ada jatuh tempo terdekat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-calendar-check','title' => 'Tidak ada jatuh tempo terdekat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card-custom">
                <div class="card-custom__header">
                    <h3>Invoice Terlambat</h3>
                    <a href="<?php echo e(route('plans.index', ['mode' => 'b', 'due_status' => 'overdue'])); ?>" class="text-small">Lihat</a>
                </div>
                <div class="card-custom__body stack gap-3">
                    <?php $__empty_1 = true; $__currentLoopData = $overdueInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="person-card">
                            <div class="avatar" style="background:var(--color-danger-soft); color:var(--color-danger);"><i class="bi bi-exclamation-triangle"></i></div>
                            <div class="person-card__meta">
                                <div class="person-card__name"><?php echo e($invoice->invoice_number); ?></div>
                                <div class="person-card__sub"><?php echo e($invoice->supplier->name); ?> · <?php echo e(Format::tanggal($invoice->due_date)); ?></div>
                            </div>
                            <div class="text-small money"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-emoji-smile','title' => 'Tidak ada invoice terlambat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-emoji-smile','title' => 'Tidak ada invoice terlambat']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header">
            <h3>Supplier dengan Sisa Tagihan Terbesar</h3>
            <a href="<?php echo e(route('suppliers.index')); ?>" class="text-small">Lihat supplier</a>
        </div>
        <div class="card-custom__body">
            <?php $__empty_1 = true; $__currentLoopData = $topSuppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $max = max(1, (int) $topSuppliers->max(fn ($row) => \App\Support\Money::toCents($row['outstanding'])));
                    $width = min(100, round(\App\Support\Money::toCents($supplier['outstanding']) / $max * 100));
                ?>
                <div style="margin-bottom:var(--space-4);">
                    <div class="cluster" style="justify-content:space-between; margin-bottom:6px;">
                        <strong class="text-small"><?php echo e($supplier['name']); ?></strong>
                        <span class="text-small money"><?php echo e(Format::rupiah($supplier['outstanding'])); ?></span>
                    </div>
                    <div class="progress-custom"><div class="progress-custom__bar" style="width:<?php echo e($width); ?>%;"></div></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-truck','title' => 'Belum ada sisa tagihan supplier']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-truck','title' => 'Belum ada sisa tagihan supplier']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <script type="application/json" id="dashboard-data">
        <?php echo json_encode([
            'monthly' => $monthlyChart,
            'status' => $statusChart,
        ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\dashboard.blade.php ENDPATH**/ ?>