<?php
    $isEdit = $user->exists;
?>

<div class="form-grid">
    <div class="col-6">
        <label class="form-label-custom" for="name">Nama <span class="text-danger">*</span></label>
        <input type="text" id="name" name="name" class="form-control-custom <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $user->name)); ?>" required maxlength="100">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-6">
        <label class="form-label-custom" for="email">Email <span class="text-danger">*</span></label>
        <input type="email" id="email" name="email" class="form-control-custom <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email', $user->email)); ?>" required maxlength="150">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-6">
        <label class="form-label-custom" for="role_id">Peran <span class="text-danger">*</span></label>
        <select id="role_id" name="role_id" class="form-select-custom form-control-custom <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <option value="">Pilih peran</option>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" <?php if((string) old('role_id', $user->role_id) === (string) $role->id): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-6">
        <label class="form-label-custom" for="password">Kata Sandi <?php echo e($isEdit ? '' : '*'); ?></label>
        <input type="password" id="password" name="password" class="form-control-custom <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php if(! $isEdit): echo 'required'; endif; ?> autocomplete="new-password" minlength="8">
        <div class="form-hint"><?php echo e($isEdit ? 'Biarkan kosong bila tidak ingin mengubah kata sandi.' : 'Minimal 8 karakter.'); ?></div>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-6">
        <label class="form-label-custom" for="password_confirmation">Konfirmasi Kata Sandi <?php echo e($isEdit ? '' : '*'); ?></label>
        <input type="password" id="password_confirmation" name="password_confirmation" class="form-control-custom" <?php if(! $isEdit): echo 'required'; endif; ?> autocomplete="new-password" minlength="8">
    </div>

    <div class="col-12">
        <label class="form-check-custom">
            <input type="hidden" name="is_active" value="0">
            <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $user->is_active ?? true)): echo 'checked'; endif; ?> <?php if($isEdit && $user->is(auth()->user())): echo 'disabled'; endif; ?>>
            <span>Akun aktif dan dapat masuk ke aplikasi</span>
        </label>
        <?php if($isEdit && $user->is(auth()->user())): ?>
            <div class="form-hint">Anda tidak dapat menonaktifkan akun sendiri.</div>
        <?php endif; ?>
    </div>
</div>

<div class="form-actions">
    <a href="<?php echo e(route('users.index')); ?>" class="btn-custom btn-outline-custom">Batal</a>
    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-check-lg"></i> <?php echo e($isEdit ? 'Simpan Perubahan' : 'Simpan Pengguna'); ?></button>
</div>
<?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\users\_form.blade.php ENDPATH**/ ?>