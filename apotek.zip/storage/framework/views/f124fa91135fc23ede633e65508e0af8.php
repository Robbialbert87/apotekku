<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Detail Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('payments.index')); ?>">Pembayaran</a></li>
                <li class="sep">/</li>
                <li class="current"><?php echo e($payment->payment_number); ?></li>
            </ol>
            <h1 class="page-header__title"><?php echo e($payment->payment_number); ?></h1>
            <p class="page-header__desc">
                <?php echo e($payment->supplier->name); ?> ·
                <span class="badge-custom <?php echo e($payment->isCancelled() ? 'badge-neutral' : 'badge-success'); ?>"><?php echo e($payment->status->label()); ?></span>
            </p>
        </div>
        <div class="page-header__actions">
            <button type="button" class="btn-custom btn-outline-custom" onclick="window.print()"><i class="bi bi-printer"></i> Cetak</button>
        </div>
    </div>

    <?php if($payment->isCancelled()): ?>
        <div class="alert-custom alert-danger-custom" role="alert">
            <i class="bi bi-x-circle-fill"></i>
            <div>
                <div class="alert-title">Pembayaran dibatalkan</div>
                <?php echo e($payment->cancel_reason); ?> — <?php echo e($payment->canceller?->name ?? 'Sistem'); ?>, <?php echo e(Format::tanggalWaktu($payment->cancelled_at)); ?>

            </div>
        </div>
    <?php endif; ?>

    <div class="content-row">
        <div class="card-custom">
            <div class="card-custom__header"><h3>Informasi Pembayaran</h3></div>
            <div class="card-custom__body">
                <div class="detail-grid detail-grid--3">
                    <div class="detail-item">
                        <div class="detail-item__label">Supplier</div>
                        <div class="detail-item__value"><a href="<?php echo e(route('suppliers.show', $payment->supplier)); ?>"><?php echo e($payment->supplier->name); ?></a></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Tanggal</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggal($payment->payment_date)); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Metode</div>
                        <div class="detail-item__value"><?php echo e($payment->method->label()); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Nomor Referensi</div>
                        <div class="detail-item__value"><?php echo e($payment->reference_number ?: '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Dicatat Oleh</div>
                        <div class="detail-item__value"><?php echo e($payment->creator?->name ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Waktu Pencatatan</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggalWaktu($payment->created_at)); ?></div>
                    </div>
                </div>

                <?php if($payment->notes): ?>
                    <div style="margin-top:var(--space-5);">
                        <div class="detail-item__label">Catatan</div>
                        <p style="margin:0;"><?php echo e($payment->notes); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($payment->proof_path): ?>
                    <div style="margin-top:var(--space-5);">
                        <div class="detail-item__label">Bukti Pembayaran</div>
                        <a href="<?php echo e(route('payments.proof', $payment)); ?>" target="_blank" class="btn-custom btn-outline-custom btn-sm-custom">
                            <i class="bi bi-paperclip"></i> Lihat Bukti
                        </a>
                        <a href="<?php echo e(route('payments.proof', [$payment, 'download' => 1])); ?>" class="btn-custom btn-ghost-custom btn-sm-custom">
                            <i class="bi bi-download"></i> Unduh
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-custom">
            <div class="card-custom__header"><h3>Ringkasan</h3></div>
            <div class="card-custom__body">
                <div class="summary-box">
                    <div class="summary-row summary-row--total"><span>Total Pembayaran</span><span class="money"><?php echo e(Format::rupiah($payment->total_amount)); ?></span></div>
                    <div class="summary-row"><span>Jumlah Invoice</span><span><?php echo e($payment->allocations->count()); ?></span></div>
                    <div class="summary-row"><span>Total Dialokasikan</span><span class="money"><?php echo e(Format::rupiah($payment->allocated_amount)); ?></span></div>
                </div>
            </div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header"><h3>Alokasi Invoice</h3></div>
        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <thead><tr><th>Invoice</th><th>Supplier</th><th>Jatuh Tempo</th><th class="text-end">Nominal</th><th>Status Invoice</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payment->allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Invoice"><a href="<?php echo e(route('invoices.show', $allocation->invoice)); ?>"><strong><?php echo e($allocation->invoice->invoice_number); ?></strong></a></td>
                            <td data-label="Supplier"><?php echo e($allocation->invoice->supplier->name); ?></td>
                            <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($allocation->invoice->due_date)); ?></td>
                            <td data-label="Nominal" class="text-end money"><?php echo e(Format::rupiah($allocation->amount)); ?></td>
                            <td data-label="Status Invoice"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $allocation->invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($allocation->invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-receipt','title' => 'Tidak ada alokasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-receipt','title' => 'Tidak ada alokasi']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="content-row">
        <div class="card-custom">
            <div class="card-custom__header"><h3>Log Aktivitas</h3></div>
            <div class="card-custom__body">
                <ul class="timeline-custom">
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="timeline-item">
                            <span class="timeline-dot"></span>
                            <div>
                                <div class="timeline-item__title"><?php echo e($log->description); ?></div>
                                <div class="timeline-item__time"><?php echo e($log->user?->name ?? 'Sistem'); ?> · <?php echo e(Format::tanggalWaktu($log->created_at)); ?></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-muted text-small">Belum ada aktivitas.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <?php if(! $payment->isCancelled() && auth()->user()->hasPermission('payment.cancel')): ?>
            <div class="card-custom">
                <div class="card-custom__header"><h3>Batalkan Pembayaran</h3></div>
                <div class="card-custom__body">
                    <p class="text-muted text-small">Pembayaran tidak dihapus, tetapi ditandai dibatalkan. Alokasi akan dikeluarkan dari perhitungan sisa tagihan.</p>
                    <form action="<?php echo e(route('payments.cancel', $payment)); ?>" method="POST" data-confirm="Batalkan pembayaran ini? Tindakan ini tercatat di log aktivitas.">
                        <?php echo csrf_field(); ?>
                        <label class="form-label-custom" for="cancel_reason">Alasan Pembatalan <span class="text-danger">*</span></label>
                        <textarea id="cancel_reason" name="cancel_reason" rows="3" class="form-control-custom" required maxlength="500" placeholder="Contoh: transfer gagal / salah input nominal."><?php echo e(old('cancel_reason')); ?></textarea>
                        <div class="form-actions" style="justify-content:flex-start;">
                            <button type="submit" class="btn-custom btn-danger-custom"><i class="bi bi-x-circle"></i> Batalkan Pembayaran</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\payments\show.blade.php ENDPATH**/ ?>