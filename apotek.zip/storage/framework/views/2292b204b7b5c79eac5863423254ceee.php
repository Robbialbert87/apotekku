<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Log Aktivitas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Log Aktivitas</li>
            </ol>
            <h1 class="page-header__title">Log Aktivitas</h1>
            <p class="page-header__desc">Jejak audit perubahan data penting di aplikasi.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('setting.view')): ?>
                <a href="<?php echo e(route('settings.edit')); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-gear"></i> Pengaturan</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header" style="flex-wrap:wrap; gap:12px;">
            <form action="<?php echo e(route('activity.index')); ?>" method="GET" class="filter-bar w-100">
                <div class="filter-field filter-field--grow">
                    <label class="form-label-custom" for="search">Cari</label>
                    <div class="input-group-custom">
                        <i class="bi bi-search"></i>
                        <input type="search" id="search" name="search" class="form-control-custom"
                               value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Aksi, deskripsi, atau nama pengguna...">
                    </div>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="date_from">Dari Tanggal</label>
                    <input type="date" id="date_from" name="date_from" class="form-control-custom" value="<?php echo e($filters['date_from'] ?? ''); ?>">
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="date_to">Sampai Tanggal</label>
                    <input type="date" id="date_to" name="date_to" class="form-control-custom" value="<?php echo e($filters['date_to'] ?? ''); ?>">
                </div>
                <div class="filter-actions">
                    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-funnel"></i> Terapkan</button>
                    <a href="<?php echo e(route('activity.index')); ?>" class="btn-custom btn-outline-custom">Reset</a>
                </div>
            </form>
        </div>

        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <thead>
                    <tr><th>Waktu</th><th>Pengguna</th><th>Aksi</th><th>Deskripsi</th><th>Alamat IP</th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $tone = match (true) {
                                str_contains($log->action, 'cancelled'), str_contains($log->action, 'voided') => 'badge-danger',
                                str_contains($log->action, 'created') => 'badge-success',
                                str_contains($log->action, 'updated'), str_contains($log->action, 'changed') => 'badge-warning',
                                default => 'badge-info',
                            };
                        ?>
                        <tr>
                            <td data-label="Waktu">
                                <strong><?php echo e(Format::tanggalWaktu($log->created_at)); ?></strong>
                            </td>
                            <td data-label="Pengguna">
                                <?php echo e($log->user?->name ?? 'Sistem'); ?>

                                <?php if($log->user?->role): ?>
                                    <div class="cell-sub"><?php echo e($log->user->role->name); ?></div>
                                <?php endif; ?>
                            </td>
                            <td data-label="Aksi">
                                <span class="badge-custom <?php echo e($tone); ?>"><?php echo e($log->action); ?></span>
                            </td>
                            <td data-label="Deskripsi">
                                <?php echo e($log->description); ?>

                                <?php if(! empty($log->properties)): ?>
                                    <div class="cell-sub"><?php echo e(\Illuminate\Support\Str::limit(json_encode($log->properties, JSON_UNESCAPED_UNICODE), 90)); ?></div>
                                <?php endif; ?>
                            </td>
                            <td data-label="Alamat IP"><?php echo e($log->ip_address ?: '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-clock-history','title' => 'Belum ada aktivitas','description' => 'Aktivitas pengguna akan tercatat di sini.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-clock-history','title' => 'Belum ada aktivitas','description' => 'Aktivitas pengguna akan tercatat di sini.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div style="padding:0 var(--space-5) var(--space-5);">
            <?php echo e($logs->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/activity/index.blade.php ENDPATH**/ ?>