<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Pembayaran</li>
            </ol>
            <h1 class="page-header__title">Pembayaran</h1>
            <p class="page-header__desc">Catat pembayaran ke supplier dan alokasikan ke satu atau beberapa invoice.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('payment.create')): ?>
                <button type="button" class="btn-custom btn-primary-custom" data-modal-open="modalPaymentCreate">
                    <i class="bi bi-plus-lg"></i> Pembayaran Baru
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header" style="flex-wrap:wrap; gap:12px;">
            <form action="<?php echo e(route('payments.index')); ?>" method="GET" class="filter-bar w-100">
                <div class="filter-field filter-field--grow">
                    <label class="form-label-custom" for="search">Cari</label>
                    <div class="input-group-custom">
                        <i class="bi bi-search"></i>
                        <input type="search" id="search" name="search" class="form-control-custom" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="No. transaksi, referensi, atau supplier...">
                    </div>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="supplier_id">Supplier</label>
                    <select name="supplier_id" id="supplier_id" class="form-select-custom form-control-custom">
                        <option value="">Semua supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>" <?php if((string) ($filters['supplier_id'] ?? '') === (string) $supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="status">Status</label>
                    <select name="status" id="status" class="form-select-custom form-control-custom">
                        <option value="">Semua</option>
                        <option value="posted" <?php if(($filters['status'] ?? '') === 'posted'): echo 'selected'; endif; ?>>Tercatat</option>
                        <option value="cancelled" <?php if(($filters['status'] ?? '') === 'cancelled'): echo 'selected'; endif; ?>>Dibatalkan</option>
                    </select>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="date_from">Dari Tanggal</label>
                    <input type="text" id="date_from" name="date_from" class="form-control-custom date-picker" value="<?php echo e($filters['date_from'] ?? ''); ?>" placeholder="dd/mm/yyyy">
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="date_to">Sampai Tanggal</label>
                    <input type="text" id="date_to" name="date_to" class="form-control-custom date-picker" value="<?php echo e($filters['date_to'] ?? ''); ?>" placeholder="dd/mm/yyyy">
                </div>
                <div class="filter-actions">
                    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-funnel"></i> Terapkan</button>
                    <a href="<?php echo e(route('payments.index')); ?>" class="btn-custom btn-outline-custom">Reset</a>
                </div>
            </form>
        </div>

        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom datatable" id="table-payments">
                <thead>
                    <tr><th>No. Transaksi</th><th>Tanggal</th><th>Supplier</th><th>Metode</th><th class="text-end">Nominal</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="No. Transaksi">
                                <a href="<?php echo e(route('payments.show', $payment)); ?>"><strong><?php echo e($payment->payment_number); ?></strong></a>
                                <?php if($payment->reference_number): ?>
                                    <div class="cell-sub">Ref: <?php echo e($payment->reference_number); ?></div>
                                <?php endif; ?>
                            </td>
                            <td data-label="Tanggal"><?php echo e(Format::tanggal($payment->payment_date)); ?></td>
                            <td data-label="Supplier"><?php echo e($payment->supplier->name); ?></td>
                            <td data-label="Metode"><?php echo e($payment->method->label()); ?></td>
                            <td data-label="Nominal" class="text-end money"><?php echo e(Format::rupiah($payment->total_amount)); ?></td>
                            <td data-label="Status">
                                <span class="badge-custom <?php echo e($payment->isCancelled() ? 'badge-neutral' : 'badge-success'); ?>"><?php echo e($payment->status->label()); ?></span>
                            </td>
                            <td data-label="">
                                <div class="table-row-actions">
                                    <a href="<?php echo e(route('payments.show', $payment)); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Detail"><i class="bi bi-eye"></i></a>
                                    <?php if(auth()->user()->hasPermission('payment.create')): ?>
                                        <form action="<?php echo e(route('payments.destroy', $payment)); ?>" method="POST" data-confirm="Hapus pembayaran ini?" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-custom btn-ghost-custom btn-sm-custom text-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-cash-stack','title' => 'Pembayaran tidak ditemukan','description' => 'Ubah filter atau catat pembayaran baru.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-cash-stack','title' => 'Pembayaran tidak ditemukan','description' => 'Ubah filter atau catat pembayaran baru.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <?php if(auth()->user()->hasPermission('payment.create')): ?>
        <?php
            $paymentSupplierId = request()->integer('supplier_id') ?: null;
            $paymentInvoiceId = request()->integer('invoice_id') ?: null;
            $paymentSupplier = $paymentSupplierId ? \App\Models\Supplier::query()->find($paymentSupplierId) : null;
            $paymentInvoices = $paymentSupplier === null
                ? collect()
                : \App\Models\Invoice::query()->outstanding()->withPaidAmount()->where('supplier_id', $paymentSupplier->id)->orderBy('due_date')->get();
        ?>
        <div class="modal-overlay" id="modalPaymentCreate">
            <div class="modal-custom" style="max-width:min(1180px, 96vw); width:100%;">
                <div class="modal-custom__header">
                    <h3 style="margin:0;">Pembayaran Baru</h3>
                    <button type="button" class="icon-btn" data-modal-close aria-label="Tutup"><i class="bi bi-x-lg"></i></button>
                </div>
                <div class="modal-custom__body">
                    <form action="<?php echo e(route('payments.store')); ?>" method="POST" enctype="multipart/form-data" data-payment-form>
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('payments._form', [
                            'suppliers' => $suppliers,
                            'supplier' => $paymentSupplier,
                            'invoices' => $paymentInvoices,
                            'invoiceId' => $paymentInvoiceId,
                            'methods' => \App\Enums\PaymentMethod::options(),
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </form>
                </div>
            </div>
        </div>

        <?php if(request()->boolean('payment_modal') || $errors->any()): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var modal = document.getElementById('modalPaymentCreate');
                    if (modal) modal.classList.add('is-open');
                });
            </script>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/payments/index.blade.php ENDPATH**/ ?>