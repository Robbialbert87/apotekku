<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Invoice'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Invoice</li>
            </ol>
            <h1 class="page-header__title">Invoice</h1>
            <p class="page-header__desc">Daftar tagihan supplier beserta status pembayaran dan jatuh tempo.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('invoice.create')): ?>
                <button type="button" class="btn-custom btn-primary-custom" data-modal-open="modalInvoiceCreate">
                    <i class="bi bi-plus-lg"></i> Invoice Baru
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header" style="flex-wrap:wrap; gap:12px;">
            <form action="<?php echo e(route('invoices.index')); ?>" method="GET" class="filter-bar w-100">
                <div class="filter-field filter-field--grow">
                    <label class="form-label-custom" for="search">Cari</label>
                    <div class="input-group-custom">
                        <i class="bi bi-search"></i>
                        <input type="search" id="search" name="search" class="form-control-custom" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Nomor invoice atau supplier...">
                    </div>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="supplier_id">Supplier</label>
                    <select name="supplier_id" id="supplier_id" class="form-select-custom form-control-custom">
                        <option value="">Semua supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>" <?php if((string) ($filters['supplier_id'] ?? '') === (string) $supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="payment_status">Status Bayar</label>
                    <select name="payment_status" id="payment_status" class="form-select-custom form-control-custom">
                        <option value="">Semua</option>
                        <?php $__currentLoopData = \App\Enums\InvoicePaymentStatus::options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(($filters['payment_status'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="due_status">Jatuh Tempo</label>
                    <select name="due_status" id="due_status" class="form-select-custom form-control-custom">
                        <option value="">Semua</option>
                        <?php $__currentLoopData = \App\Enums\DueStatus::options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(($filters['due_status'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="date_from">Dari Tanggal</label>
                    <input type="text" id="date_from" name="date_from" class="form-control-custom date-picker" value="<?php echo e($filters['date_from'] ?? ''); ?>" placeholder="dd/mm/yyyy">
                </div>
                <div class="filter-field">
                    <label class="form-label-custom" for="date_to">Sampai Tanggal</label>
                    <input type="text" id="date_to" name="date_to" class="form-control-custom date-picker" value="<?php echo e($filters['date_to'] ?? ''); ?>" placeholder="dd/mm/yyyy">
                </div>
                <div class="filter-field">
                    <label class="form-label-custom">Tampilkan</label>
                    <label class="form-check-custom" style="height:38px;">
                        <input type="checkbox" name="include_voided" value="1" <?php if($filters['include_voided'] ?? false): echo 'checked'; endif; ?>>
                        <span class="text-small">Invoice dibatalkan</span>
                    </label>
                </div>
                <div class="filter-actions">
                    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-funnel"></i> Terapkan</button>
                    <a href="<?php echo e(route('invoices.index')); ?>" class="btn-custom btn-outline-custom">Reset</a>
                </div>
            </form>
        </div>

        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom datatable" id="table-invoices">
                <thead>
                    <tr>
                        <th>Invoice</th><th>Supplier</th><th>Jatuh Tempo</th><th class="text-end">Total</th>
                        <th class="text-end">Dibayar</th><th class="text-end">Sisa</th><th>Status</th><th>Jatuh Tempo</th><th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Invoice">
                                <a href="<?php echo e(route('invoices.show', $invoice)); ?>"><strong><?php echo e($invoice->invoice_number); ?></strong></a>
                                <div class="cell-sub"><?php echo e(Format::tanggal($invoice->invoice_date)); ?></div>
                                <?php if($invoice->isVoided()): ?>
                                    <span class="badge-custom badge-neutral">Dibatalkan</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="Supplier"><?php echo e($invoice->supplier->name); ?></td>
                            <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($invoice->due_date)); ?></td>
                            <td data-label="Total" class="text-end money"><?php echo e(Format::rupiah($invoice->total_amount)); ?></td>
                            <td data-label="Dibayar" class="text-end money"><?php echo e(Format::rupiah($invoice->paid_amount)); ?></td>
                            <td data-label="Sisa" class="text-end money"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></td>
                            <td data-label="Status"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            <td data-label="Jatuh Tempo"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->due_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->due_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            <td data-label="">
                                <div class="table-row-actions">
                                    <a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Detail"><i class="bi bi-eye"></i></a>
                                    <?php if(auth()->user()->hasPermission('invoice.update')): ?>
                                        <form action="<?php echo e(route('invoices.destroy', $invoice)); ?>" method="POST" data-confirm="Hapus invoice ini?" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-custom btn-ghost-custom btn-sm-custom text-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if(! $invoice->isVoided() && auth()->user()->hasPermission('payment.create') && ! $invoice->isPaid()): ?>
                                        <a href="<?php echo e(route('payments.create', ['supplier_id' => $invoice->supplier_id, 'invoice_id' => $invoice->id])); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Catat pembayaran"><i class="bi bi-cash"></i></a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="9"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-receipt','title' => 'Invoice tidak ditemukan','description' => 'Ubah filter atau tambahkan invoice baru.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-receipt','title' => 'Invoice tidak ditemukan','description' => 'Ubah filter atau tambahkan invoice baru.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <?php if(auth()->user()->hasPermission('invoice.create')): ?>
        <div class="modal-overlay" id="modalInvoiceCreate">
            <div class="modal-custom" style="max-width:min(920px, 95vw); width:100%;">
                <div class="modal-custom__header">
                    <h3 style="margin:0;">Invoice Baru</h3>
                    <button type="button" class="icon-btn" data-modal-close aria-label="Tutup"><i class="bi bi-x-lg"></i></button>
                </div>
                <div class="modal-custom__body" style="padding: var(--space-4);">
                    <?php
                        $invoice = new \App\Models\Invoice();
                        $items = collect();
                        $files = collect();
                    ?>
                    <form action="<?php echo e(route('invoices.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('invoices._form', ['modal' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </form>
                </div>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var modal = document.getElementById('modalInvoiceCreate');
                    if (modal) modal.classList.add('is-open');
                });
            </script>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\invoices\index.blade.php ENDPATH**/ ?>