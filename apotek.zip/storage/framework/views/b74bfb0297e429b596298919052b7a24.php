<?php $__env->startSection('title', 'Peran & Hak Akses'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('users.index')); ?>">Pengguna</a></li>
                <li class="sep">/</li>
                <li class="current">Peran</li>
            </ol>
            <h1 class="page-header__title">Peran &amp; Hak Akses</h1>
            <p class="page-header__desc">Atur izin untuk setiap peran. Peran Admin selalu memiliki akses penuh.</p>
        </div>
        <div class="page-header__actions">
            <a href="<?php echo e(route('users.index')); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-people"></i> Daftar Pengguna</a>
        </div>
    </div>

    <div class="stat-grid stat-grid--3" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));">
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="stat-card">
                <div class="stat-card__top">
                    <div class="stat-card__icon" style="background:<?php echo e($role->isAdmin() ? 'var(--color-primary-soft)' : 'var(--color-info-soft)'); ?>; color:<?php echo e($role->isAdmin() ? 'var(--color-primary)' : 'var(--color-info)'); ?>;">
                        <i class="bi <?php echo e($role->isAdmin() ? 'bi-shield-lock-fill' : 'bi-person-badge'); ?>"></i>
                    </div>
                    <?php if($role->is_system): ?>
                        <span class="badge-custom badge-neutral">Sistem</span>
                    <?php endif; ?>
                </div>
                <div class="stat-card__value" style="font-size:var(--fs-h4);"><?php echo e($role->name); ?></div>
                <div class="stat-card__label">
                    <?php echo e($role->users_count); ?> pengguna · <?php echo e($role->isAdmin() ? 'semua izin' : $role->permissions->count().' izin'); ?>

                </div>
                <div style="margin-top:var(--space-3);">
                    <?php if($role->isAdmin()): ?>
                        <span class="text-muted text-small">Akses penuh otomatis</span>
                    <?php elseif(auth()->user()->hasPermission('role.update')): ?>
                        <a href="<?php echo e(route('roles.edit', $role)); ?>" class="btn-custom btn-outline-custom btn-sm-custom">
                            <i class="bi bi-sliders"></i> Atur Izin
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card-custom">
        <div class="card-custom__header">
            <h3>Ringkasan Hak Akses</h3>
        </div>
        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <thead>
                    <tr><th>Peran</th><th>Deskripsi</th><th>Pengguna</th><th>Izin</th><th></th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="Peran"><strong><?php echo e($role->name); ?></strong><div class="cell-sub"><?php echo e($role->slug); ?></div></td>
                            <td data-label="Deskripsi"><?php echo e($role->description ?: '-'); ?></td>
                            <td data-label="Pengguna"><?php echo e($role->users_count); ?></td>
                            <td data-label="Izin">
                                <?php if($role->isAdmin()): ?>
                                    <span class="badge-custom badge-success">Akses penuh</span>
                                <?php else: ?>
                                    <span class="badge-custom badge-info"><?php echo e($role->permissions->count()); ?> izin</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="">
                                <div class="table-row-actions">
                                    <?php if(! $role->isAdmin() && auth()->user()->hasPermission('role.update')): ?>
                                        <a href="<?php echo e(route('roles.edit', $role)); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" title="Atur izin"><i class="bi bi-pencil"></i></a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/roles/index.blade.php ENDPATH**/ ?>