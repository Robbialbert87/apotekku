<?php if($paginator->hasPages()): ?>
    <div class="pagination-wrap">
        <div class="pagination-info">
            Menampilkan <?php echo e($paginator->firstItem()); ?>–<?php echo e($paginator->lastItem()); ?> dari <?php echo e($paginator->total()); ?> data
        </div>
        <nav aria-label="Navigasi halaman">
            <ul class="pagination-custom">
                <?php if($paginator->onFirstPage()): ?>
                    <li><span class="page-btn is-disabled"><i class="bi bi-chevron-left"></i></span></li>
                <?php else: ?>
                    <li><a class="page-btn" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><i class="bi bi-chevron-left"></i></a></li>
                <?php endif; ?>

                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_string($element)): ?>
                        <li><span class="page-btn is-disabled"><?php echo e($element); ?></span></li>
                    <?php endif; ?>

                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                                <li><span class="page-btn is-active"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                                <li><a class="page-btn" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($paginator->hasMorePages()): ?>
                    <li><a class="page-btn" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><i class="bi bi-chevron-right"></i></a></li>
                <?php else: ?>
                    <li><span class="page-btn is-disabled"><i class="bi bi-chevron-right"></i></span></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\partials\pagination.blade.php ENDPATH**/ ?>