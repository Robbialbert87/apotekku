<?php use \App\Support\Format; ?>
<?php use \App\Support\Money; ?>

<?php
    $isEdit = $invoice->exists;
    $paidCents = $isEdit ? Money::toCents($invoice->paid_amount) : 0;
    $locked = $paidCents > 0;
    $itemRows = old('items', $items->map(fn ($item) => [
        'name' => $item->name,
        'quantity' => rtrim(rtrim((string) $item->quantity, '0'), '.'),
        'unit' => $item->unit,
    ])->all());
    $itemRows = empty($itemRows) ? [['name' => '', 'quantity' => '', 'unit' => '']] : array_values($itemRows);
?>

<p class="text-muted text-small" style="margin:0 0 var(--space-4);">
    Field bertanda <span class="text-danger">*</span> wajib diisi.
</p>

<div class="content-row">
    <div class="card-custom">
        <div class="card-custom__header"><h3>Informasi Invoice</h3></div>
        <div class="card-custom__body">
            <div class="form-grid">
                <div class="col-12">
                    <label class="form-label-custom" for="supplier_id">Supplier <span class="text-danger">*</span></label>
                    <select id="supplier_id" name="supplier_id" class="form-select-custom form-control-custom <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required <?php if($locked): echo 'disabled'; endif; ?>>
                        <option value="">Pilih supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($option->id); ?>" <?php if((string) old('supplier_id', $invoice->supplier_id) === (string) $option->id): echo 'selected'; endif; ?>>
                                <?php echo e($option->name); ?><?php echo e($option->is_active ? '' : ' (nonaktif)'); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($locked): ?>
                        <input type="hidden" name="supplier_id" value="<?php echo e($invoice->supplier_id); ?>">
                        <div class="form-hint">Supplier tidak dapat diubah karena invoice sudah memiliki pembayaran.</div>
                    <?php endif; ?>
                    <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label-custom" for="invoice_number">Nomor Invoice <span class="text-danger">*</span></label>
                    <input type="text" id="invoice_number" name="invoice_number" class="form-control-custom text-uppercase <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('invoice_number', $invoice->invoice_number)); ?>" required maxlength="100" placeholder="INV-0001">
                    <div class="form-hint">Unik untuk setiap supplier.</div>
                    <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label-custom" for="total_amount">Total Tagihan <span class="text-danger">*</span></label>
                    <div class="currency-input">
                        <span class="currency-input__prefix">Rp</span>
                        <input type="text" id="total_amount" name="total_amount" inputmode="numeric"
                               class="form-control-custom <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('total_amount', $isEdit ? Format::rupiah($invoice->total_amount, false) : '')); ?>"
                               data-currency-input required <?php if($locked): echo 'readonly'; endif; ?>>
                    </div>
                    <?php if($locked): ?>
                        <div class="form-hint">Total terkunci karena sudah ada pembayaran. Batalkan pembayaran untuk mengoreksi.</div>
                    <?php endif; ?>
                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label-custom" for="notes">Catatan</label>
                    <textarea id="notes" name="notes" rows="3" class="form-control-custom <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="2000"
                              placeholder="Catatan internal mengenai invoice ini."><?php echo e(old('notes', $invoice->notes)); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header"><h3>Tanggal</h3></div>
        <div class="card-custom__body">
            <div class="form-grid">
                <div class="col-12">
                    <label class="form-label-custom" for="invoice_date">Tanggal Invoice <span class="text-danger">*</span></label>
                    <input type="text" id="invoice_date" name="invoice_date" class="form-control-custom date-picker <?php $__errorArgs = ['invoice_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('invoice_date', $invoice->invoice_date?->toDateString())); ?>" placeholder="dd/mm/yyyy" required>
                    <?php $__errorArgs = ['invoice_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label-custom" for="received_date">Tanggal Diterima</label>
                    <input type="text" id="received_date" name="received_date" class="form-control-custom date-picker <?php $__errorArgs = ['received_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('received_date', $invoice->received_date?->toDateString())); ?>" placeholder="dd/mm/yyyy">
                    <?php $__errorArgs = ['received_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label class="form-label-custom" for="due_date">Jatuh Tempo <span class="text-danger">*</span></label>
                    <input type="text" id="due_date" name="due_date" class="form-control-custom date-picker <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('due_date', $invoice->due_date?->toDateString())); ?>" placeholder="dd/mm/yyyy" required>
                    <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card-custom">
    <div class="card-custom__header">
        <h3>Rincian Obat</h3>
        <button type="button" class="btn-custom btn-outline-custom btn-sm-custom" data-add-item>
            <i class="bi bi-plus-lg"></i> Tambah
        </button>
    </div>
    <div class="card-custom__body">
        <p class="text-muted text-small" style="margin:-8px 0 var(--space-4);">Opsional. Cukup nama dan jumlah obat, tanpa harga.</p>

        <div class="item-rows" data-item-rows>
            <?php $__currentLoopData = $itemRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-row" data-item-row>
                    <input type="text" name="items[<?php echo e($index); ?>][name]" class="form-control-custom item-name" value="<?php echo e($item['name'] ?? ''); ?>" placeholder="Nama obat" maxlength="150">
                    <input type="text" name="items[<?php echo e($index); ?>][quantity]" class="form-control-custom" value="<?php echo e($item['quantity'] ?? ''); ?>" placeholder="Jumlah" inputmode="decimal">
                    <input type="text" name="items[<?php echo e($index); ?>][unit]" class="form-control-custom" value="<?php echo e($item['unit'] ?? ''); ?>" placeholder="Satuan" maxlength="30">
                    <button type="button" class="btn-custom btn-ghost-custom" data-remove-item title="Hapus baris"><i class="bi bi-trash"></i></button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php $__errorArgs = ['items.*.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['items.*.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div style="margin-top:var(--space-5); padding-top:var(--space-5); border-top:1px solid var(--color-border);">
            <h3 class="form-section__title">Lampiran</h3>
            <p class="text-muted text-small" style="margin:-8px 0 var(--space-4);">Foto atau PDF invoice, maksimal <?php echo e(config('apotek.upload.max_kb', 5120) / 1024); ?> MB per file (maksimal 5 file).</p>

            <?php if($files->isNotEmpty()): ?>
                <ul class="file-list" style="margin-bottom:var(--space-4);">
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="file-icon"><i class="bi <?php echo e($file->isImage() ? 'bi-image' : 'bi-file-earmark-pdf'); ?>"></i></div>
                            <div class="file-meta">
                                <div class="file-name"><?php echo e($file->original_name); ?></div>
                                <div class="file-size"><?php echo e(Format::fileSize($file->size)); ?></div>
                            </div>
                            <a href="<?php echo e(route('invoices.files.show', [$invoice, $file])); ?>" class="btn-custom btn-ghost-custom btn-sm-custom" target="_blank"><i class="bi bi-eye"></i></a>
                            <form action="<?php echo e(route('invoices.files.destroy', [$invoice, $file])); ?>" method="POST" data-confirm="Hapus lampiran ini?">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-custom btn-ghost-custom btn-sm-custom" title="Hapus"><i class="bi bi-trash"></i></button>
                            </form>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <input type="file" name="files[]" class="form-control-custom" accept=".jpg,.jpeg,.png,.webp,.pdf" multiple>
            <?php $__errorArgs = ['files.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>

<div class="form-actions">
    <a href="<?php echo e($isEdit ? route('invoices.show', $invoice) : route('invoices.index')); ?>" class="btn-custom btn-outline-custom">Batal</a>
    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-check-lg"></i> <?php echo e($isEdit ? 'Simpan Perubahan' : 'Simpan Invoice'); ?></button>
</div><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/invoices/_form.blade.php ENDPATH**/ ?>