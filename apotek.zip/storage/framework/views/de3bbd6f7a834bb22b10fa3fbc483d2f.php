<?php $__env->startSection('title', 'Invoice Baru'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('invoices.index')); ?>">Invoice</a></li>
                <li class="sep">/</li>
                <li class="current">Baru</li>
            </ol>
            <h1 class="page-header__title">Invoice Baru</h1>
            <p class="page-header__desc">Catat tagihan dari supplier obat.</p>
        </div>
    </div>

    <?php if($suppliers->isEmpty()): ?>
        <div class="alert-custom alert-warning-custom" role="alert">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <div>Belum ada supplier aktif. <a href="<?php echo e(route('suppliers.create')); ?>">Tambahkan supplier terlebih dahulu</a>.</div>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('invoices.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('invoices._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\invoices\create.blade.php ENDPATH**/ ?>