<?php $__env->startSection('title', 'Ubah Supplier'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('suppliers.index')); ?>">Supplier</a></li>
                <li class="sep">/</li>
                <li class="current">Ubah</li>
            </ol>
            <h1 class="page-header__title">Ubah Supplier</h1>
            <p class="page-header__desc"><?php echo e($supplier->name); ?></p>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__body">
            <form action="<?php echo e(route('suppliers.update', $supplier)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('suppliers._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\suppliers\edit.blade.php ENDPATH**/ ?>