<?php
    $isEdit = $supplier->exists;
?>

<p class="text-muted text-small" style="margin:0 0 var(--space-4);">
    Field bertanda <span class="text-danger">*</span> wajib diisi.
</p>

<div class="supplier-form-columns">
    <section class="supplier-form-column">
        <h3 class="supplier-form-column__title">Identitas Supplier</h3>
        <p class="supplier-form-column__desc">Data utama dan kontak supplier.</p>

        <div>
            <label class="form-label-custom" for="name">Nama Supplier <span class="text-danger">*</span></label>
            <input type="text" id="name" name="name" autocomplete="organization"
                   class="form-control-custom <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('name', $supplier->name)); ?>" required maxlength="150"
                   placeholder="Contoh: PT Kimia Farma" aria-required="true">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="form-label-custom" for="phone">Nomor Telepon <span class="text-danger">*</span></label>
            <input type="tel" id="phone" name="phone" inputmode="tel" autocomplete="tel"
                   class="form-control-custom <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('phone', $supplier->phone)); ?>" required maxlength="30"
                   placeholder="08xxxxxxxxxx" aria-required="true">
            <div class="form-hint">Gunakan nomor yang dapat dihubungi.</div>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="form-label-custom" for="contact_name">Nama Kontak</label>
            <input type="text" id="contact_name" name="contact_name" autocomplete="name"
                   class="form-control-custom <?php $__errorArgs = ['contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('contact_name', $supplier->contact_name)); ?>" maxlength="150"
                   placeholder="Nama PIC">
            <?php $__errorArgs = ['contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </section>

    <section class="supplier-form-column">
        <h3 class="supplier-form-column__title">Alamat & Catatan</h3>
        <p class="supplier-form-column__desc">Alamat lengkap dan informasi tambahan.</p>

        <div>
            <label class="form-label-custom" for="address">Alamat <span class="text-danger">*</span></label>
            <textarea id="address" name="address" rows="4"
                      class="form-control-custom <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      required maxlength="1000" placeholder="Alamat lengkap supplier"
                      aria-required="true"><?php echo e(old('address', $supplier->address)); ?></textarea>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="form-label-custom" for="notes">Catatan</label>
            <textarea id="notes" name="notes" rows="4"
                      class="form-control-custom <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      maxlength="1000" placeholder="Informasi tambahan seperti termin pembayaran atau jam operasional."><?php echo e(old('notes', $supplier->notes)); ?></textarea>
            <div class="form-hint">Opsional. Maksimal 1000 karakter.</div>
            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <label class="form-check-custom">
            <input type="hidden" name="is_active" value="0">
            <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $supplier->is_active ?? true)): echo 'checked'; endif; ?>>
            <span>Supplier aktif dan dapat dipilih pada invoice baru</span>
        </label>
        <div class="form-hint">Supplier nonaktif tidak akan muncul saat membuat invoice baru.</div>
    </section>
</div>

<div class="form-actions">
    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn-custom btn-outline-custom">Batal</a>
    <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-check-lg"></i> <?php echo e($isEdit ? 'Simpan Perubahan' : 'Simpan Supplier'); ?></button>
</div><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/suppliers/_form.blade.php ENDPATH**/ ?>