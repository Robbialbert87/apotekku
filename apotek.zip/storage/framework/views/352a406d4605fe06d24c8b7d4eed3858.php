<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Pembayaran Baru'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('payments.index')); ?>">Pembayaran</a></li>
                <li class="sep">/</li>
                <li class="current">Baru</li>
            </ol>
            <h1 class="page-header__title">Pembayaran Baru</h1>
            <p class="page-header__desc">Seluruh nominal pembayaran wajib dialokasikan ke invoice dari supplier yang sama.</p>
        </div>
    </div>

    <?php echo $__env->make('payments._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\payments\create.blade.php ENDPATH**/ ?>