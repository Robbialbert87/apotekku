<?php $__env->startSection('title', 'Ubah Pengguna'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('users.index')); ?>">Pengguna</a></li>
                <li class="sep">/</li>
                <li class="current"><?php echo e($user->name); ?></li>
            </ol>
            <h1 class="page-header__title">Ubah Pengguna</h1>
            <p class="page-header__desc"><?php echo e($user->email); ?></p>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__body">
            <form action="<?php echo e(route('users.update', $user)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('users._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\users\edit.blade.php ENDPATH**/ ?>