<?php $__env->startSection('title', 'Atur Hak Akses'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $selected = old('permissions', $role->permissions->pluck('id')->all());
        $selected = array_map('intval', (array) $selected);
    ?>

    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('users.index')); ?>">Pengguna</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('roles.index')); ?>">Peran</a></li>
                <li class="sep">/</li>
                <li class="current"><?php echo e($role->name); ?></li>
            </ol>
            <h1 class="page-header__title">Hak Akses <?php echo e($role->name); ?></h1>
            <p class="page-header__desc"><?php echo e($role->description ?: 'Centang izin yang boleh digunakan oleh peran ini.'); ?></p>
        </div>
        <div class="page-header__actions">
            <a href="<?php echo e(route('roles.index')); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
        </div>
    </div>

    <form action="<?php echo e(route('roles.update', $role)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="card-custom">
            <div class="card-custom__header" style="flex-wrap:wrap; gap:12px;">
                <h3>Daftar Izin</h3>
                <div class="cluster gap-2">
                    <button type="button" class="btn-custom btn-ghost-custom btn-sm-custom" data-permission-toggle="all">Pilih semua</button>
                    <button type="button" class="btn-custom btn-ghost-custom btn-sm-custom" data-permission-toggle="none">Kosongkan</button>
                </div>
            </div>

            <div class="card-custom__body">
                <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="alert-custom alert-danger-custom" style="margin-bottom:var(--space-4);"><i class="bi bi-exclamation-triangle-fill"></i><div><?php echo e($message); ?></div></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-section" style="margin-bottom:var(--space-5);">
                        <div class="cluster" style="justify-content:space-between; margin-bottom:var(--space-3);">
                            <h4 class="form-section__title" style="margin:0; font-size:var(--fs-small); text-transform:uppercase; letter-spacing:0.04em; color:var(--color-text-muted);"><?php echo e($group); ?></h4>
                            <button type="button" class="btn-custom btn-ghost-custom btn-sm-custom" data-permission-toggle="group" data-permission-scope="<?php echo e($loop->index); ?>">Pilih grup</button>
                        </div>

                        <div class="form-grid" data-permission-group="<?php echo e($loop->index); ?>">
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6">
                                    <label class="form-check-custom" style="align-items:flex-start;">
                                        <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php if(in_array($permission->id, $selected, true)): echo 'checked'; endif; ?> data-permission-checkbox>
                                        <span>
                                            <strong style="display:block;"><?php echo e($permission->name); ?></strong>
                                            <span class="text-muted text-small"><?php echo e($permission->slug); ?></span>
                                        </span>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="form-actions">
            <a href="<?php echo e(route('roles.index')); ?>" class="btn-custom btn-outline-custom">Batal</a>
            <button type="submit" class="btn-custom btn-primary-custom"><i class="bi bi-check-lg"></i> Simpan Hak Akses</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\roles\edit.blade.php ENDPATH**/ ?>