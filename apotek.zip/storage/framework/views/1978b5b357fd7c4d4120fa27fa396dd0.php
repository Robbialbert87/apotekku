<?php use \App\Support\Format; ?>

<?php $__env->startSection('title', 'Detail Supplier'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('suppliers.index')); ?>">Supplier</a></li>
                <li class="sep">/</li>
                <li class="current"><?php echo e($supplier->name); ?></li>
            </ol>
            <h1 class="page-header__title"><?php echo e($supplier->name); ?></h1>
            <p class="page-header__desc">
                <span class="badge-custom <?php echo e($supplier->is_active ? 'badge-success' : 'badge-neutral'); ?>"><?php echo e($supplier->is_active ? 'Aktif' : 'Nonaktif'); ?></span>
                <span class="text-muted text-small" style="margin-left:8px;"><?php echo e($supplier->invoices_count); ?> invoice tercatat</span>
            </p>
        </div>
        <div class="page-header__actions">
            <a href="<?php echo e(route('suppliers.index')); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-arrow-left"></i> Kembali</a>
            <?php if(auth()->user()->hasPermission('invoice.create')): ?>
                <a href="<?php echo e(route('invoices.create', ['supplier_id' => $supplier->id])); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-receipt"></i> Invoice Baru</a>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('payment.create')): ?>
                <a href="<?php echo e(route('payments.create', ['supplier_id' => $supplier->id])); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-cash-stack"></i> Catat Pembayaran</a>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('supplier.update')): ?>
                <a href="<?php echo e(route('suppliers.edit', $supplier)); ?>" class="btn-custom btn-primary-custom"><i class="bi bi-pencil"></i> Ubah</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="content-row">
        <div class="card-custom">
            <div class="card-custom__header"><h3>Informasi Supplier</h3></div>
            <div class="card-custom__body">
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-item__label">Nama Kontak</div>
                        <div class="detail-item__value"><?php echo e($supplier->contact_name ?: '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Telepon</div>
                        <div class="detail-item__value"><?php echo e($supplier->phone); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Alamat</div>
                        <div class="detail-item__value"><?php echo e($supplier->address); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Catatan</div>
                        <div class="detail-item__value"><?php echo e($supplier->notes ?: '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Ditambahkan</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggalWaktu($supplier->created_at)); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item__label">Terakhir Diubah</div>
                        <div class="detail-item__value"><?php echo e(Format::tanggalWaktu($supplier->updated_at)); ?></div>
                    </div>
                </div>

                <?php if(auth()->user()->hasPermission('supplier.deactivate')): ?>
                    <form action="<?php echo e(route('suppliers.toggle-status', $supplier)); ?>" method="POST" data-confirm="Ubah status supplier ini?" style="margin-top:var(--space-5);">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn-custom <?php echo e($supplier->is_active ? 'btn-outline-custom' : 'btn-success-custom'); ?>">
                            <i class="bi <?php echo e($supplier->is_active ? 'bi-pause-circle' : 'bi-play-circle'); ?>"></i>
                            <?php echo e($supplier->is_active ? 'Nonaktifkan Supplier' : 'Aktifkan Supplier'); ?>

                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-custom">
            <div class="card-custom__header">
                <h3>Invoice Terakhir</h3>
                <a href="<?php echo e(route('invoices.index', ['supplier_id' => $supplier->id])); ?>" class="text-small">Lihat semua</a>
            </div>
            <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
                <table class="table-custom">
                    <thead><tr><th>Invoice</th><th>Jatuh Tempo</th><th>Sisa</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Invoice">
                                    <a href="<?php echo e(route('invoices.show', $invoice)); ?>"><strong><?php echo e($invoice->invoice_number); ?></strong></a>
                                    <div class="cell-sub"><?php echo e(Format::tanggal($invoice->invoice_date)); ?></div>
                                </td>
                                <td data-label="Jatuh Tempo"><?php echo e(Format::tanggal($invoice->due_date)); ?></td>
                                <td data-label="Sisa" class="money"><?php echo e(Format::rupiah($invoice->remaining_amount)); ?></td>
                                <td data-label="Status"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $invoice->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoice->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-receipt','title' => 'Belum ada invoice']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-receipt','title' => 'Belum ada invoice']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__header">
            <h3>Pembayaran Terakhir</h3>
            <a href="<?php echo e(route('payments.index', ['supplier_id' => $supplier->id])); ?>" class="text-small">Lihat semua</a>
        </div>
        <div class="table-wrap table-responsive-cards" style="border:none; border-radius:0;">
            <table class="table-custom">
                <thead><tr><th>No. Transaksi</th><th>Tanggal</th><th>Metode</th><th>Nominal</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="No. Transaksi"><a href="<?php echo e(route('payments.show', $payment)); ?>"><strong><?php echo e($payment->payment_number); ?></strong></a></td>
                            <td data-label="Tanggal"><?php echo e(Format::tanggal($payment->payment_date)); ?></td>
                            <td data-label="Metode"><?php echo e($payment->method->label()); ?></td>
                            <td data-label="Nominal" class="money"><?php echo e(Format::rupiah($payment->total_amount)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4"><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'bi-cash-stack','title' => 'Belum ada pembayaran']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bi-cash-stack','title' => 'Belum ada pembayaran']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\suppliers\show.blade.php ENDPATH**/ ?>