<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li class="current">Pengaturan</li>
            </ol>
            <h1 class="page-header__title">Pengaturan</h1>
            <p class="page-header__desc">Informasi apotek, preferensi default sistem, dan keamanan akun Anda.</p>
        </div>
        <div class="page-header__actions">
            <?php if(auth()->user()->hasPermission('activity.view')): ?>
                <a href="<?php echo e(route('activity.index')); ?>" class="btn-custom btn-outline-custom"><i class="bi bi-clock-history"></i> Log Aktivitas</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="content-row">
        <!-- Kolom Kiri: Identitas Apotek & Preferensi Sistem -->
        <div class="stack gap-4">
            <form action="<?php echo e(route('settings.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="card-custom">
                    <div class="card-custom__header">
                        <div>
                            <h3 style="margin:0;"><i class="bi bi-building"></i> Identitas Apotek</h3>
                            <p class="text-muted text-small" style="margin:2px 0 0 0;">Informasi resmi yang ditampilkan pada header invoice dan laporan.</p>
                        </div>
                    </div>
                    <div class="card-custom__body">
                        <div class="form-grid">
                            <div class="col-8">
                                <label class="form-label-custom" for="apotek_name">Nama Apotek <span class="text-danger">*</span></label>
                                <input type="text" id="apotek_name" name="apotek_name"
                                       class="form-control-custom <?php $__errorArgs = ['apotek_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('apotek_name', $settings['apotek_name'])); ?>" required maxlength="150" placeholder="Contoh: Apotek Farma Sehat">
                                <?php $__errorArgs = ['apotek_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-4">
                                <label class="form-label-custom" for="apotek_phone">Telepon</label>
                                <input type="text" id="apotek_phone" name="apotek_phone"
                                       class="form-control-custom <?php $__errorArgs = ['apotek_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('apotek_phone', $settings['apotek_phone'])); ?>" maxlength="30" placeholder="08xxxxxxxxxx">
                                <?php $__errorArgs = ['apotek_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-4">
                                <label class="form-label-custom" for="apotek_email">Email</label>
                                <input type="email" id="apotek_email" name="apotek_email"
                                       class="form-control-custom <?php $__errorArgs = ['apotek_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('apotek_email', $settings['apotek_email'])); ?>" maxlength="150" placeholder="info@apotek.com">
                                <?php $__errorArgs = ['apotek_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-8">
                                <label class="form-label-custom" for="apotek_address">Alamat Lengkap</label>
                                <textarea id="apotek_address" name="apotek_address" rows="2"
                                          class="form-control-custom <?php $__errorArgs = ['apotek_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                          maxlength="1000" placeholder="Alamat lengkap lokasi apotek..."><?php echo e(old('apotek_address', $settings['apotek_address'])); ?></textarea>
                                <?php $__errorArgs = ['apotek_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-custom" style="margin-top:var(--space-4);">
                    <div class="card-custom__header">
                        <div>
                            <h3 style="margin:0;"><i class="bi bi-sliders"></i> Preferensi Operasional</h3>
                            <p class="text-muted text-small" style="margin:2px 0 0 0;">Nilai default transaksi invoice dan cetakan dokumen.</p>
                        </div>
                    </div>
                    <div class="card-custom__body">
                        <div class="form-grid">
                            <div class="col-6">
                                <label class="form-label-custom" for="invoice_due_days">Jatuh Tempo Default (hari) <span class="text-danger">*</span></label>
                                <input type="number" id="invoice_due_days" name="invoice_due_days" min="1" max="365"
                                       class="form-control-custom <?php $__errorArgs = ['invoice_due_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('invoice_due_days', $settings['invoice_due_days'])); ?>" required>
                                <div class="form-hint">Saran tanggal jatuh tempo otomatis saat input invoice baru.</div>
                                <?php $__errorArgs = ['invoice_due_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-6">
                                <label class="form-label-custom" for="report_footer">Catatan Kaki Laporan</label>
                                <input type="text" id="report_footer" name="report_footer"
                                       class="form-control-custom <?php $__errorArgs = ['report_footer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('report_footer', $settings['report_footer'])); ?>" maxlength="255" placeholder="Teks catatan kaki pada dokumen cetak">
                                <div class="form-hint">Teks ringkas yang tertera di kaki cetakan laporan.</div>
                                <?php $__errorArgs = ['report_footer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <?php if(auth()->user()->hasPermission('setting.update')): ?>
                            <div class="form-actions" style="margin-top:var(--space-5); padding-top:var(--space-4); border-top:1px solid var(--color-border);">
                                <a href="<?php echo e(route('dashboard')); ?>" class="btn-custom btn-outline-custom">Batal</a>
                                <button type="submit" class="btn-custom btn-primary-custom">
                                    <i class="bi bi-check-lg"></i> Simpan Pengaturan
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>

        <!-- Kolom Kanan: Keamanan Akun & Info Sistem -->
        <div class="stack gap-4">
            <!-- Form Ganti Kata Sandi -->
            <div class="card-custom">
                <div class="card-custom__header">
                    <div>
                        <h3 style="margin:0;"><i class="bi bi-shield-lock"></i> Keamanan Akun</h3>
                        <p class="text-muted text-small" style="margin:2px 0 0 0;">Perbarui kata sandi login akun Anda.</p>
                    </div>
                </div>
                <div class="card-custom__body">
                    <form action="<?php echo e(route('settings.password')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-grid">
                            <div class="col-12">
                                <label class="form-label-custom" for="current_password">Kata Sandi Saat Ini <span class="text-danger">*</span></label>
                                <input type="password" id="current_password" name="current_password"
                                       class="form-control-custom <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required autocomplete="current-password" placeholder="••••••••">
                                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <label class="form-label-custom" for="password">Kata Sandi Baru <span class="text-danger">*</span></label>
                                <input type="password" id="password" name="password"
                                       class="form-control-custom <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required autocomplete="new-password" minlength="8" placeholder="Minimal 8 karakter">
                                <div class="form-hint">Minimal 8 karakter.</div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error-text"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <label class="form-label-custom" for="password_confirmation">Konfirmasi Kata Sandi Baru <span class="text-danger">*</span></label>
                                <input type="password" id="password_confirmation" name="password_confirmation"
                                       class="form-control-custom"
                                       required autocomplete="new-password" minlength="8" placeholder="Ulangi kata sandi baru">
                            </div>
                        </div>

                        <div class="form-actions" style="margin-top:var(--space-4);">
                            <button type="submit" class="btn-custom btn-primary-custom w-100" style="justify-content:center;">
                                <i class="bi bi-key-fill"></i> Ganti Kata Sandi
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Ringkasan Info Sistem -->
            <div class="card-custom">
                <div class="card-custom__header">
                    <div>
                        <h3 style="margin:0;"><i class="bi bi-info-circle"></i> Info Akun & Sistem</h3>
                        <p class="text-muted text-small" style="margin:2px 0 0 0;">Detail sesi pengguna aktif.</p>
                    </div>
                </div>
                <div class="card-custom__body">
                    <div class="summary-box">
                        <div class="summary-row">
                            <span>Pengguna</span>
                            <strong><?php echo e(auth()->user()->name); ?></strong>
                        </div>
                        <div class="summary-row">
                            <span>Email</span>
                            <span class="text-muted"><?php echo e(auth()->user()->email); ?></span>
                        </div>
                        <div class="summary-row">
                            <span>Hak Akses</span>
                            <span class="badge-custom badge-info"><?php echo e(auth()->user()->role?->name ?? 'User'); ?></span>
                        </div>
                        <div class="summary-row">
                            <span>Zona Waktu</span>
                            <span><?php echo e(config('app.timezone')); ?></span>
                        </div>
                        <div class="summary-row">
                            <span>Bahasa</span>
                            <span>Indonesia (<?php echo e(config('app.locale')); ?>)</span>
                        </div>
                        <div class="summary-row">
                            <span>Mata Uang</span>
                            <span>Rupiah (IDR)</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views/settings/edit.blade.php ENDPATH**/ ?>