<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk · <?php echo e(config('apotek.name')); ?></title>
    <script>
        (function () {
            try {
                var theme = localStorage.getItem('hms-theme') === 'dark' ? 'dark' : 'light';
                document.documentElement.setAttribute('data-theme', theme);
            } catch (e) {
                document.documentElement.setAttribute('data-theme', 'light');
            }
        })();
    </script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="auth-page">
<div class="auth-card">
    <div class="auth-brand">
        <div class="auth-brand-mark">A</div>
        <strong><?php echo e(config('apotek.name')); ?></strong>
    </div>

    <div style="text-align:center; margin-bottom:var(--space-6);">
        <h1 style="font-size:var(--fs-h3); margin-bottom:6px;">Selamat datang kembali</h1>
        <p class="text-muted text-small" style="margin:0;">Masuk untuk mengelola invoice dan pembayaran supplier.</p>
    </div>

    <?php if(session('status')): ?>
        <div class="alert-custom alert-success-custom" role="status" style="margin-bottom:var(--space-4);">
            <i class="bi bi-check-circle-fill"></i><div><?php echo e(session('status')); ?></div>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert-custom alert-danger-custom" role="alert" style="margin-bottom:var(--space-4);">
            <i class="bi bi-exclamation-triangle-fill"></i><div><?php echo e($errors->first()); ?></div>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('login.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div style="margin-bottom:14px;">
            <label class="form-label-custom" for="email">Email</label>
            <input type="email" name="email" id="email" class="form-control-custom <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('email')); ?>" placeholder="nama@apotek.com" required autofocus autocomplete="username">
        </div>

        <div style="margin-bottom:18px;">
            <label class="form-label-custom" for="password">Kata Sandi</label>
            <input type="password" name="password" id="password" class="form-control-custom <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="••••••••" required autocomplete="current-password">
        </div>

        <div class="cluster" style="justify-content:space-between; margin-bottom:18px;">
            <label class="form-check-custom">
                <input type="checkbox" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?>>
                <span class="text-small">Ingat saya</span>
            </label>
        </div>

        <button type="submit" class="btn-custom btn-primary-custom w-100" style="justify-content:center;">
            <i class="bi bi-box-arrow-in-right"></i> Masuk
        </button>
    </form>

    <p class="auth-note">Akses hanya untuk pengguna yang terdaftar dan aktif.</p>
</div>
</body>
</html>
<?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\auth\login.blade.php ENDPATH**/ ?>