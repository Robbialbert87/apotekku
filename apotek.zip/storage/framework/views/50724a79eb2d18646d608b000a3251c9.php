<?php $__env->startSection('title', 'Ubah Invoice'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <ol class="breadcrumb-custom">
                <li><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('invoices.index')); ?>">Invoice</a></li>
                <li class="sep">/</li>
                <li><a href="<?php echo e(route('invoices.show', $invoice)); ?>"><?php echo e($invoice->invoice_number); ?></a></li>
                <li class="sep">/</li>
                <li class="current">Ubah</li>
            </ol>
            <h1 class="page-header__title">Ubah Invoice</h1>
            <p class="page-header__desc"><?php echo e($invoice->invoice_number); ?> · <?php echo e($invoice->supplier->name); ?></p>
        </div>
    </div>

    <div class="card-custom">
        <div class="card-custom__body">
            <form action="<?php echo e(route('invoices.update', $invoice)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('invoices._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robbi\Herd\apotek\resources\views\invoices\edit.blade.php ENDPATH**/ ?>